<?php
require ("addit/opencommon.php");
if(isset($_SESSION['email']))
{
    header('location: openindex.php');
}
?>
<!DOCTYPE html>
<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome | Life Style Store</title>
        <!-- Bootstrap Core CSS -->
        <link href="stylecss/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="stylecss/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="json/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="json/bootstrap.min.js"></script>
    </head>
    <body>
    <?php
    include "addit/openheader.php"
    ?>
    <div class="container">
    <div class="row">
    <div class="col-lg-7">
        <img src="img/yess.jpg" alt="">
        </div>
        <div class="col-lg-5">
        <div class="panel panel-default">
        <div class="panel-header">
        SIGNUP
        </div>
        <div class="panel-body">
        <form ACTION="opensignupscript.php" METHOD="POST">
        <div class="form-group">
        <input type="text" placeholder="Name" name="name" class="form-control">
        </div>
        <div class="form-group">
        <input type="email" placeholder="E-mail" name="email" class="form-control">
        </div>
        <div class="form-group">
        <input type="password" placeholder="password" name="password" class="form-control">
        </div>
        <div class="form-group">
        <input type="number" placeholder="contact" name="contact" class="form-control">
        </div>
        <div class="form-group">
        <input type="text" placeholder="city" name="city" class="form-control">
        </div>
        <button type="submit" name ="submit" class="btn btn-primary"> SignUP</button>
        </form>
        </div>
        <div class="panel-footer" >
        </div>
        </div>
        </div>
        </div>
        </div>
        <?php
        include "addit/openfooter.php"
        ?>
        </body>
        </html>

                     