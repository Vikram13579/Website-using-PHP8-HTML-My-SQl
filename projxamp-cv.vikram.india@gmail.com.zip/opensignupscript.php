<?php
require("addit/opencommon.php");
$e=$_POST['name'];
$e=mysqli_real_escape_string($con,$e);
$a=$_POST['email'];
$a=mysqli_real_escape_string($con,$a);
$b=$_POST['password'];
$b=mysqli_real_escape_string($con,$b);
$v=$_POST['contact'];
$v=mysqli_real_escape_string($con,$v);
$n=$_POST['city'];
$n=mysqli_real_escape_string($con,$n);
$c=MD5($b);
$check="SELECT * FROM customer WHERE email='$a'";
$res = mysqli_query($con, $check)or die($mysqli_error($con));
$rows=mysqli_num_rows($res);
if($rows!=0)
{
    $m = "<span class='red'>Email Already Exists</span>";
    header('location: opensignup.php?m1=' . $m);
}else{
$d="INSERT INTO customer (name,email,password,contact,city) VALUES ('" . $e . "','" . $a . "','" . $c . "','" . $v . "','" . $n . "')";
mysqli_query($con,$d) or die(mysqli_error($con));
$user_id = mysqli_insert_id($con);
    $_SESSION['email'] = $email;
    $_SESSION['user_id'] = $user_id;
    header('location: openindex.php');
}