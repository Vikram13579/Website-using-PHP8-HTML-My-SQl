<?php
require ("addit/opencommon.php");
?>
<!DOCTYPE html>
<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome | Life Style Store</title>
        <!-- Bootstrap Core CSS -->
        <link href="stylecss/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="stylecss/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="json/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="json/bootstrap.min.js"></script>
    </head>
    <body>
    <?php
    include "addit/openheader.php"
    ?>
    <div class="container">
    <div class="row">
    <div class="col-xs-8">
    <h2> LIVE SUPPORT </h2>
    <h4> 24 HOURS | 7 DAYS A WEEK | 365 DAYS A YEAR LIVE TECHINCAL SUPPORT </h4>
    <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters. There are many variations of passages of Lorel Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
    </div>
    <div class="col-xs-4">
    <div class="thumbnail">
    <img align="right" src="img/contact.png" alt="">
    </div>
    </div>
    </div>
    <div class="row">
    <div class="col-lg-9">
    <form id="main-contact-form" class="contact-form row" name="contact-form" method="post" action="sendemail.php">
				    
                    <div class="form-group col-sm-9">
				        <input type="text" name="name" class="form-control" required="required" placeholder="Name" >
				    </div>
				    
                    <div class="form-group col-sm-9">
				        <input type="email" name="email" class="form-control" required="required" placeholder="Email">
				    </div>
				    
                    <div class="form-group col-sm-9">
				        <textarea name="message" id="message" required="required" class="form-control" rows="7" placeholder="Your Message Here"></textarea>
				    </div>
				            
                    <div class="form-group col-sm-7">
				                <input type="submit" name="submit" class="btn btn-primary" value="Submit">
				    </div>
				</form>
    </div>
    <div class="col-lg-3">
    <h3> COMPANY INFO </h3>
    <address>
				    <p>500 Lorem Ipsum Dolar Sit,</p>
				    <p>22-56-3-5 Sit Amet, Lorem,</p>
				    <p>USA</p>
				    <p>Phone:(00) 222 555 3333</p>
				    <p>Fax:(000) 222 55 33 6</p>
				    <p>Email: info@estore.com</p>
	               </address>
                   
    </div>
    </div>
    </div>
    </body>
    </html>
