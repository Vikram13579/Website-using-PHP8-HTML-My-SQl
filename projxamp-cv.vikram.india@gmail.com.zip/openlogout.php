<?php
session_start();
if (!isset($_SESSION['email'])) {
    header('location: openlogin.php');
}
session_destroy();
header('location: openindex.php');
?> 