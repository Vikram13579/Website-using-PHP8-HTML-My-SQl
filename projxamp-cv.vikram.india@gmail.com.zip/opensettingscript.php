<?php
require ("addit/opencommon.php");
if (!isset($_SESSION['email'])) {
    header('location: index.php');
}
$a=$_POST['oldpassword'];
$a=MD5($a);
$b=$_POST['newpassword'];
$b=MD5($b);
$c=$_POST['retypassword'];
$c=MD5($c);

$check="SELECT email, password FROM customer WHERE email ='" . $_SESSION['email'] . "'";
$res = mysqli_query($con, $check)or die($mysqli_error($con));
$rows=mysqli_fetch_array($res);
$d=$rows['password'];
if($b!=$c)
{
    header('location: opensettings.php?error=The two passwords don\'t match.');
}
else
{
   if($d==$a)
   {
    $query = "UPDATE  customer SET password = '" . $b . "' WHERE email = '" . $_SESSION['email'] . "'";
    mysqli_query($con, $query) or die($mysqli_error($con));
    header('location: openindex.php?error=Password Updated Successfully');
   }
   else{
    header('location: opensettings.php?error=The oldpassword is wrong.');

   }
}
?>
