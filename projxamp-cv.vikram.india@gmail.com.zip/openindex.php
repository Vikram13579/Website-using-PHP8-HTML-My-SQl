<?php
require "addit/opencommon.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome | Life Style Store</title>
        <!-- Bootstrap Core CSS -->
        <link href="stylecss/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="stylecss/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="json/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="json/bootstrap.min.js"></script>
    </head>
    <body>
    <?php
    include "addit/openheader.php";
    ?>
        <div class="container">
       <div class="row text-center">
           <div class="col-lg-4">
               <div class="panel panel-default">
                   <div class ="panel-heading">
                       <h6>Camera 1</h6>
                    </div>
                    <div class="panel-body">
                    <div class="thumbnail">
                        <img src="img/1.jpg" alt="">
                        </div>
                        NIXON</br>price:40000
                    </div>
                    <div class ="panel-footer">
                        <?php if(isset($_SESSION['email'])){?>
                            <a href="openaddcart.php?id=2" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                        <?php
                        }
                        else{
                            ?>
                            <a href="openlogin.php" class="btn btn-primary">buy now</a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
               <div class="panel panel-default">
                   <div class ="panel-heading">
                       <h6>Camera 2</h6>
                    </div>
                    <div class="panel-body">
                    <div class="thumbnail">
                        <img src="img/2.jpg" alt="">
                        </div>
                        DSLR</br>price:60000
                    </div>
                    <div class ="panel-footer">
                        <?php if(isset($_SESSION['email'])){?>
                            <a href="openaddcart.php?id=1" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                        <?php
                        }
                        else{
                            ?>
                            <a href="openlogin.php" class="btn btn-primary">buy now</a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
               <div class="panel panel-default">
                   <div class ="panel-heading">
                       <h6>Camera 3</h6>
                    </div>
                    <div class="panel-body">
                    <div class="thumbnail">
                        <img src="img/3.jpg" alt="">
                        </div>
                        SONY</br>
                        price:69000
                    </div>
                    <div class ="panel-footer">
                        <?php if(isset($_SESSION['email'])){?>
                            <a href="openaddcart.php?id=3" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                        <?php
                        }
                        else{
                            ?>
                            <a href="openlogin.php" class="btn btn-primary">buy now</a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            </div>
            <div class="container">
       <div class="row text-center">
           <div class="col-lg-4">
               <div class="panel panel-default">
                   <div class ="panel-heading">
                       <h6>Watch 1</h6>
                    </div>
                    <div class="panel-body">
                    <div class="thumbnail">
                        <img src="img/18.jpg" alt="">
                        </div>
                        SONATA</br>price:88000
                    </div>
                    <div class ="panel-footer">
                        <?php if(isset($_SESSION['email'])){?>
                            <a href="openaddcart.php?id=4" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                        <?php
                        }
                        else{
                            ?>
                            <a href="openlogin.php" class="btn btn-primary">buy now</a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
               <div class="panel panel-default">
                   <div class ="panel-heading">
                       <h6>Watch 2</h6>
                    </div>
                    <div class="panel-body">
                    <div class="thumbnail">
                        <img src="img/19.jpg" alt="">
                        </div>
                        ROLEX</br>price:45000
                    </div>
                    <div class ="panel-footer">
                        <?php if(isset($_SESSION['email'])){?>
                            <a href="openaddcart.php?id=5" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                        <?php
                        }
                        else{
                            ?>
                            <a href="openlogin.php" class="btn btn-primary">buy now</a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
               <div class="panel panel-default">
                   <div class ="panel-heading">
                       <h6>Watch 3</h6>
                    </div>
                    <div class="panel-body">
                    <div class="thumbnail">
                        <img src="img/20.jpg" alt="">
                        </div>
                        DIAMOND</br>price:65000
                    </div>
                    <div class ="panel-footer">
                        <?php if(isset($_SESSION['email'])){?>
                            <a href="openaddcart.php?id=6" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                        <?php
                        }
                        else{
                            ?>
                            <a href="openlogin.php" class="btn btn-primary">buy now</a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            </div>
            <div class="container">
       <div class="row text-center">
           <div class="col-lg-4">
               <div class="panel panel-default">
                   <div class ="panel-heading">
                       <h6>Shirt 1</h6>
                    </div>
                    <div class="panel-body">
                    <div class="thumbnail">
                        <img src="img/22.jpg" alt="">
                        </div>
                        USPOLO</br>price:60000
                    </div>
                    <div class ="panel-footer">
                        <?php if(isset($_SESSION['email'])){?>
                            <a href="openaddcart.php?id=7" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                        <?php
                        }
                        else{
                            ?>
                            <a href="openlogin.php" class="btn btn-primary">buy now</a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
               <div class="panel panel-default">
                   <div class ="panel-heading">
                       <h6>Shirt 2</h6>
                    </div>
                    <div class="panel-body">
                    <div class="thumbnail">
                        <img src="img/24.jpg" alt="">
                        </div>
                        PEPE</br>price:35000
                    </div>
                    <div class ="panel-footer">
                        <?php if(isset($_SESSION['email'])){?>
                            <a href="openaddcart.php?id=8" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                        <?php
                        }
                        else{
                            ?>
                            <a href="openlogin.php" class="btn btn-primary">buy now</a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
               <div class="panel panel-default">
                   <div class ="panel-heading">
                       <h6>Mobile 1</h6>
                    </div>
                    <div class="panel-body">
                    <div class="thumbnail">
                        <img src="img/e6.jpg" alt="">
                        </div>
                        Iphone</br>price:28000
                    </div>
                    <div class ="panel-footer">
                        <?php if(isset($_SESSION['email'])){?>
                            <a href="openaddcart.php?id=9" name="add" value="add" class="btn btn-block btn-primary">Add to cart</a>
                        <?php
                        }
                        else{
                            ?>
                            <a href="openlogin.php" class="btn btn-primary">buy now</a>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            </div>
       
           
            
            <?php
                        include "addit/openfooter.php";
                        ?>
                    </body>
    </html>