-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 24, 2021 at 06:24 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `email`, `password`, `contact`, `city`) VALUES
(1, 'Vikramadithya', 'cvvikram@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '2111111111', 'ANANTAPUR'),
(2, 'Kairevu', 'kairevuvikram@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '2118183976', 'ANANTAPUR'),
(3, 'Kairevu', 'kairevu.vikram13579@gmail.com', 'e6a7457cff3497cccbdbf8cdb01ded98', '1222121212', 'ANANTAPUR'),
(4, 'Prathima', 'prathima292003@gmail.com', 'd41d8cd98f00b204e9800998ecf8427e', '1151489756', 'ANANTAPUR'),
(5, 'Prathya', 'prathma321@gmail.com', 'fe2110ca3375dc4dfbfa7b564b6bac0d', '1111111111', 'ANANTAPUR'),
(6, 'Kairevu', 'cv.vikram.india@gmail.com', '98da403beacb4029e791c9e00e9d3561', '9632587410', 'ANANTAPUR');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`) VALUES
(1, 'NIXON', 40000),
(2, 'DSLR', 60000),
(3, 'SONY', 69000),
(4, 'SONATA', 88000),
(5, 'ROLEX', 45000),
(6, 'DIAMOND', 65000),
(7, 'USPOLO', 60000),
(8, 'PEPE', 35000),
(9, 'IPHONE', 28000),
(10, 'ONEPLUS 3T', 31000),
(11, 'ONEPLUS 5', 34000),
(12, 'ONEPLUS 5T', 36000),
(13, 'XIAOMI REDMI NOTE 4', 13000),
(14, 'MI A1', 15000),
(15, 'MI MAX 2', 16000),
(16, 'MI MIX 2', 36000);

-- --------------------------------------------------------

--
-- Table structure for table `users_items`
--

DROP TABLE IF EXISTS `users_items`;
CREATE TABLE IF NOT EXISTS `users_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `status` enum('Added to cart','Confirmed') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_items`
--

INSERT INTO `users_items` (`id`, `user_id`, `item_id`, `status`) VALUES
(2, 1, 6, 'Confirmed'),
(3, 1, 3, 'Confirmed'),
(4, 2, 4, 'Added to cart'),
(5, 1, 4, 'Confirmed'),
(6, 1, 6, 'Added to cart'),
(10, 3, 8, 'Added to cart'),
(11, 3, 4, 'Added to cart'),
(12, 5, 5, 'Added to cart'),
(13, 5, 9, 'Added to cart'),
(14, 5, 8, 'Added to cart'),
(15, 6, 7, 'Added to cart');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
