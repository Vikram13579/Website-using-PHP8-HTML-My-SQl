<?php
require "addit/opencommon.php";
if(isset($_SESSION['email']))
{
    header('location: openindex.php');
}
?>
<!DOCTYPE html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome | Life Style Store</title>
        <!-- Bootstrap Core CSS -->
        <link href="stylecss/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="stylecss/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="json/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="json/bootstrap.min.js"></script>
    </head>
    <body>
    <?php
    include "addit/openheader.php";
    ?>
    <div class="container">
    <div class="form-popup ">
    <div class="col-xs-6 col-xs-offset-3">
    <form action="openloginscript.php" method="post" class="form-container">
    <h3> LOGIN </h3>
    <div class="form-group">
    <input type="email" class="form-control" name="email" placeholder="E-MAIL">
    </div>
    <div class="form-group">
    <input type="password" class="form-control" name="password" placeholder="PASSWORD">
    </div>
    <button type="submit" name ="submit" class="btn btn-primary"> LOGIN</button>
    </form>
    </div>
    </div>
    </div>
    <?php
    include "addit/openfooter.php"
    ?>
    </body>
    </html>