<?php
require ("addit/opencommon.php");
?>
<!DOCTYPE html>
<html>
<head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Welcome | Life Style Store</title>
        <!-- Bootstrap Core CSS -->
        <link href="stylecss/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="stylecss/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="json/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="json/bootstrap.min.js"></script>
    </head>
    <body>
    <?php 
    include "addit/openheader.php";
    ?>
    <div class="container">
    <div class="col-xs-6 col-xs-offset-3">
    <form ACTION="opensettingscript.php" METHOD="POST">
    <div class="form-group">
    <input class="form-control" type="password" name="oldpassword" placeholder="old-holder">
    </div>
    <div class="form-group">
    <input class="form-control" type="password" name="newpassword" placeholder="New-holder">
    </div>
    <div class="form-group">
    <input class="form-control" type="password" name="retypassword" placeholder="Retypassword">
    </div>
    <button type="submit" name="submit" class="btn btn-primary"> SUBMIT</button>
    </form>
    </div>
    </div>
    <?php
    include "addit/openfooter.php";
    ?>
    </body>
    </html>